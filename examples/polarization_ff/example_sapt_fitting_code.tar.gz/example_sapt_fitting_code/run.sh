#!/bin/bash

./fitenergy bf4_pbe0_tot.bohr bf4_param testout
